/* tricky.c */

/***
 *** a tricky comment ******/

int main(void)
{
    char c = 0X0, *s;
    int x = 0x7fffFFFF;

    s = "I said \"hello there\"";
    c ++;
    --s;
}
